from colorama import Fore
def main():
    color1 = Fore.RED
    print(color1 + "Hello!")
if __name__ == '__main__':
    main()